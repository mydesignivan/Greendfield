<h3>Ein- und Mehrtagestouren in Mendoza und Umgebung</h3>

<ul class="list-style1">
    <li>Puente del Inca</li>
    <li>Minas de Paramillos</li>
    <li>Bodegas und Camino del Vino</li>
    <li>Bosque Telteca</li>
    <li>Manzano Histórico</li>
    <li>Cañón de Atuel</li>
    <li>Laguna del Diamante</li>
    <li>Ala Delta, Hang-Gliding, Parapente</li>
    <li>Rafting auf dem Río Mendoza</li>
    <li>Rafting auf dem Río Atuel</li>
    <li>Überquerung der Anden mit Pferden: Von Tupungato-Mendoza nach Chile</li>
    <li>Abenteuer Cordón Del Plata</li>
    <li>Cerro Aconcagua</li>
    <li>Observatorio und Sternwarte El Leoncito</li>
    <li>Barreal und Río de los Patos</li>
    <li>Hiking – Trekking</li>
    <li>Klettern und Bergsteigen</li>
    <li>Windsurfing in Potrerillos</li>
    <li>Sportfliegen und Flugschein</li>
    <li>...und etliches mehr.</li>
</ul>

<h3>Regionen in Argentinien:</h3>
<ul class="list-style1">
    <li>Iguazú-Wasserfälle</li>
    <li>Península Valdés an der Atlantikküste</li>
    <li>Perito-Moreno-Gletscher in Patagonien</li>
    <li>Ushuaia, die südlichste Stadt der Welt</li>
    <li>Bariloche mit dem Seengebiet am Fuße der Südanden</li>
    <li>Andenpässe nach Chile</li>
    <li>Provinzen Salta und Jujuy, als von der Indiokultur geprägter Norden</li>
    <li>Tren de las nubes</li>
    <li>Sierras de Córdoba</li>
    <li>Sierras de San Luis</li>
    <li>Buenos Aires als Kulturerlebnis</li>
    <li>Südliches Patagonien mit Trekking</li>
    <li>Araukarienwälder der Südanden</li>
    <li>Hochanden, Gletscher, Vulkane, Salzseen und Gebirgswüsten in den Provinzen San Juan, Catamarca, La Rioja, Salta und Jujuy</li>
    <li>...und etliches mehr.</li>
    <li>Zum Einstimmen können Sie vor ab die angegebenen Begriffe aus de Internet erforschen.</li>
</ul>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
