<h3>Freiwilligenarbeit - Freiwilligeneins&auml;tze - Volunteering</h3>
<p>Sie wollen einfach etwas Sinnvolles tun? In den folgenden Projekten und Institutionen können Sie sich persönlich über Freiwilligenarbeit einbringen. Sie lernen Ihre eigenen sozialen Neigungen durch Ihr Engagement kennen und ernten wertvolle Erfahrungen zu zwischenmenschlichen und naturbezogenen Problemstellungen in Lateinamerika. Wir organisieren dies vor Ort für Sie.</p>
<p>Ihr Einsatz ist in der Regel in Projekten im Bereich Umweltschutz, Tierschutz, Naturreservate, Sozialarbeit, Kinder- und Jugendarbeit, NGOs, Kranken- und Heilberufe usw. angesiedelt. Wegen der Distanz zum Ort oder der Einrichtung für Ihre Freiwilligenarbeit ist es bisweilen ratsam bzw. notwendig, dass auch Ihre Unterkunft direkt mit dieser Institution in Verbindung steht oder sich in unmittelbarer Nähe befindet. Bei der Organisation der Unterkunft können wir in Einzelfällen eventuell helfen.</p>

<p>Ihr  Einsatz 1: Bosque Telteca</p>
<p>Ihr  Einsatz 2: Zoológico de Mendoza</p>
<p>Ihr  Einsatz 3: Waisenhaus xxxx</p>
<p>Ihr  Einsatz 4: Altenheim xxxx</p>
<p>Ihr  Einsatz 5: Parque Provincial Aconcagua</p>
<p>Ihr  Einsatz 6: </p>
<p>Ihr  Einsatz 7: </p>
<p>Ihr  Einsatz 8: </p>
<p>Ihr  Einsatz 9: </p>

<p>Wichtig: Die Freiwilligeneinsätze müssen Sie in Kombination mit einem mindestens 4-wöchigen Spanischkurs buchen!</p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
