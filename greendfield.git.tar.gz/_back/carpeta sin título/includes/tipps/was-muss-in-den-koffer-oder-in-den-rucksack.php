<h3>Was muss in den Koffer oder in den Rucksack</h3>

<p>Dies hängt vor allem davon ab, zu welcher Jahreszeit Sie nach Mendoza kommen und vor allem, welches Reise- und Erlebnisprogramm Sie sich für Mendoza und Argentinien vorgenommen haben. Dabei ist zu bedenken, dass Argentinien über nahzu alle Klimazonen und orographische Höhenunterschiede verfügt (siehe Klima).</p>
<p>Gleichzeitig dürfen Sie ebenfalls darauf vertrauen, dass es in Argentinien all die Konsum- und Kleidungsgegenstände gibt, die Sie auch gerne in Deutschland tragen bzw. kaufen würden; nur eben...zum Grossteil viel preiswerter, da Argentinien derzeit eines der günstigsten Reiseländer Lateinamerikas ist, nachdem der Peso zum Ende 2001 abgewertet wurde. Das heisst, dass Sie Ihren Koffer oder Rucksack nicht mit allen notwendigen Dingen vollpacken müssen (das gilt ebenfalls für Medikamente), falls Sie sich ebenfalls in Argentinien das Eine oder Andere zum Anziehen oder als Outdoorausrüstung leisten können.</p>
<p>Trotzdem legen Sie Wert darauf, dass folgende Dinge zu Ihrer Grundausrüstung gehören: </p>
<p>Mosquitonetz; spezielle Medikamente, auf die Sie auch zuhause angewiesen sind; Notebook; MP4; Sprachlexikon deutsch-spanisch-deutsch; Sonnenbrille etc.</p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/tipps-fur-sie.php'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
