<h3>Voluntariat</h3>
<ul>
<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/wer-kann-an-unserem-programm-teilnehmen.php?returnpage=voluntariat.php'}, 2); return false;"><img src="images/iconos/quien_puede_participar.png" alt="" border="0" /> Wer kann an unserem Programm teilnehmen</a></li>

<li><a href="Bewerbungsablauf-Praktikas-und-Voluntariat.pdf"><img src="images/iconos/procedimiento_de_inscripcion_formularios.png" alt="" border="0" /> Bewerbungsablauf Praktikas und Voluntariat</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/download-des-anmeldeformulares_1.php?returnpage=voluntariat.php'}, 6); return false;"><img src="images/iconos/download_formularios.png" alt="" border="0" /> Anmeldeformulare</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/teilnahmebedingungen.php?returnpage=voluntariat.php'}, 7); return false;"><img src="images/iconos/condiciones_participar.png" alt="" border="0" /> Teilnahmebedingungen</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/einstufungstest-zu-ihren-spanischkenntnissen.php?returnpage=voluntariat.php'}, 8); return false;"><img src="images/iconos/test_categorizacion_de_su_conocimiento_en_espanol.png" alt="" border="0" /> Einstufungstest zu Ihren Spanischkenntnissen</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/ihre-anreise.php?returnpage=voluntariat.php'}, 9); return false;"><img src="images/iconos/su_viaje_de_ida.png" alt="" border="0" /> Ihre Anreise</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/ihre-unterkunft.php?returnpage=voluntariat.php'}, 10); return false;"><img src="images/iconos/su_hospedaje.png" alt="" border="0" /> Ihre Unterkunft</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/wie-geht-es-weiter.php?returnpage=voluntariat.php&filename=Preisliste_2010_Green_Fields3.html'}, 11); return false;"><img src="images/iconos/como_seguir.png" alt="" border="0" /> Wie geht es weiter?</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/nicht-im-preis-enthalten.php?returnpage=voluntariat.php'}, 12); return false;"><img src="images/iconos/lo_que_no_esta_dentro_del_precio.png" alt="" border="0" /> Nicht im Preis enthalten</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/zahlungsmodalitaten.php?returnpage=voluntariat.php'}, 13); return false;"><img src="images/iconos/modalidades_pago.png" alt="" border="0" /> Zahlungsmodalit&auml;ten</a></li>

<li><a href="#" onclick="Slider.slide({url: 'includes/secciones/vertraulichkeitserklarung.php?returnpage=voluntariat.php'}, 14); return false;"><img src="images/iconos/declaracion_confidencialidad.png" alt="" border="0" /> Vertraulichkeitserkl&auml;rung</a></li>

</ul>
