<div class="stickies-verde"><h3><a href="sprachkurse.php">Sprachkurse in Spanisch +Fachspanisch</a></h3></div>
<div class="stickies-naranja"><h3><a href="fachpraktika.php">Fachpraktika</a></h3></div>
<div class="stickies-rosa"><h3><a href="voluntariat.php">Voluntariat<br />Freiwillgenarbeit</a></h3></div>
<div class="stickies-azul"><h3><a href="angebot-im-einzelnen.php">Unser umfangreiches Angebot im Einzelnen</a></h3></div>