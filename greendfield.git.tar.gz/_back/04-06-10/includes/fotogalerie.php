<h3>Fotogalerie</h3>

<div id="container-photos">
    <div class="content-photos">
        <ul>
            <li><a class="group" rel="group" href="images/gallery//gallery_Argentinische_Wildpferde.jpg"><img src="images/gallery/thumbs/gallery_Argentinische_Wildpferde.jpg" alt="" title="" border="0" width="128" /></a></li>
            <li><a class="group" rel="group" href="images/gallery/gallery_Asado_am_Wegesrand_unter_Freunden_Tradition_an_jedem_Ort.jpg"><img src="images/gallery/thumbs/gallery_Asado_am_Wegesrand_unter_Freunden_Tradition_an_jedem_Ort.jpg" alt="" title="" border="0" width="128" /></a></li>
            <li><a class="group" rel="group" href="images/gallery/gallery_Asado_Costillares_de_Vaca.jpg"><img src="images/gallery/thumbs/gallery_Asado_Costillares_de_Vaca.jpg" alt="" title="" border="0" width="128" /></a></li>
            <li><a class="group" rel="group" href="images/gallery/gallery_Asado_Criollo.jpg"><img src="images/gallery/thumbs/gallery_Asado_Criollo.jpg" alt="" title="" border="0" width="128" /></a></li>
            <li><a class="group" rel="group" href="images/gallery/gallery_Asado_daheim.jpg"><img src="images/gallery/thumbs/gallery_Asado_daheim.jpg" alt="" title="" border="0" width="128" /></a></li>
            <li><a class="group" rel="group" href="images/gallery/gallery_Asado_de_Cordero.jpg"><img src="images/gallery/thumbs/gallery_Asado_de_Cordero.jpg" alt="" title="" border="0" width="128" /></a></li>
            <li><a class="group" rel="group" href="images/gallery/gallery_Asado_de_Cordero2.jpg"><img src="images/gallery/thumbs/gallery_Asado_de_Cordero2.jpg" alt="" title="" border="0" width="128" /></a></li>
            <li><a class="group" rel="group" href="images/gallery/thumbs/gallery_Ausgetrocknete_Tonpfanne_im_trockenen_Mendoza.jpg"><img src="images/gallery/gallery_Ausgetrocknete_Tonpfanne_im_trockenen_Mendoza.jpg" alt="" title="" border="0" width="128" /></a></li>
        </ul>
    </div>
    <div class="pagination"></div>
</div>

