<h3>Argentinien</h3>
<ul>
<li><a href="#" onclick="Slider.slide({url: 'includes/die-geographie.php'}, 6); return false;"><img src="images/iconos/geografia2.png" alt="" border="0" /> Die Geographie</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/das-klima.php'}, 7); return false;"><img src="images/iconos/clima3.png" alt="" border="0" /> Das Klima</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/das-land.php'}, 8); return false;"><img src="images/iconos/pais.png" alt="" border="0" /> Das Land</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/regionen-in-argentinien.php'}, 9); return false;"><img src="images/iconos/regiones_argentina.png" alt="" border="0" /> Regionen in Argentinien</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/die-soziale-struktur-argentiniens.php'}, 10); return false;"><img src="images/iconos/estructura_social.png" alt="" border="0" /> Die Soziale Struktur Argentiniens</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/kulturelle-beziehungen.php'}, 11); return false;"><img src="images/iconos/relaciones_culturales_argentina_alemania.png" alt="" border="0" /> Kulturelle Beziehungen</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/wirtschaftsbeziehungen.php'}, 12); return false;"><img src="images/iconos/relaciones_econ_argentina_alemania.png" alt="" border="0" /> Wirtschaftsbeziehungen</a></li>
</ul>
<h3>Mendoza</h3>
<ul>
<li><a href="#" onclick="Slider.slide({url: 'includes/strassenkarte.php', callback: set_images}, 13); return false;"><img src="images/iconos/mapa_vial.png" alt="" border="0" /> Strassenkarte</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/die-provinz.php'}, 14); return false;"><img src="images/iconos/provincia.png" alt="" border="0" /> Die Provinz</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/der-weinbau.php'}, 15); return false;"><img src="images/iconos/vinicultura1.png" alt="" border="0" /> Der Weinbau</a></li>
<li><a href="http://cultura.mendoza.gov.ar/cultura/" target="_blank"><img src="images/iconos/agenda_cultural2.png" alt="" border="0" /> Kultur- und Veranstaltungskalender</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/die-stadt.php'}, 17); return false;"><img src="images/iconos/ciudad.png" alt="" border="0" /> Die Stadt</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/stadtplan-von-mendoza-und-umgebung.php'}, 18); return false;"><img src="images/iconos/mapa_ciudad.png" alt="" border="0" /> Stadtplan von Mendoza und Umgebung</a></li>
</ul>