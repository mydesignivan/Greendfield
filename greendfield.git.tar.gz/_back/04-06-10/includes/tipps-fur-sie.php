<h3>TIPPs f&uuml;r Sie</h3>
<ul>
<li><a href="#" onclick="Slider.slide({url: 'includes/tipps/sicherheits-und-gesundheitsvorsorge.php'}, 19); return false;"><img src="images/iconos/prevencion_seguridad_salud.png" alt="" border="0" /> Sicherheits- und Gesundheitsvorsorge</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/tipps/was-muss-in-den-koffer-oder-in-den-rucksack.php'}, 20); return false;"><img src="images/iconos/con_que_hay_que_llenar_la_maleta.png" alt="" border="0" /> Was muss in den Koffer oder in den Rucksack</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/tipps/geldbeschaffung-preise-und-kosten.php'}, 21); return false;"><img src="images/iconos/pasantias_tecnicas.png" alt="" border="0" /> Geldbeschaffung, Preise und Kosten</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/tipps/offizielle-information-zu-argentinien.php'}, 22); return false;"><img src="images/iconos/informaciones_oficiales_respecto_argentina.png" alt="" border="0" /> Offizielle Information zu Argentinien</a></li>
<li><a href="#" onclick="Slider.slide({url: 'includes/tipps/interessante-und-wichtige-links.php'}, 23); return false;"><img src="images/iconos/links_interesantes_importantes.png" alt="" border="0" /> Interessante und wichtige LINKs</a></li>
</ul>