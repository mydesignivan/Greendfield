<h3>Strassenkarte</h3>
<p>
    <iframe width="525" height="350" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="http://maps.google.com/maps/ms?ie=UTF8&amp;hl=en&amp;msa=0&amp;msid=113252492302745252179.000484b2d0f7b533059f1&amp;ll=-32.895011,-68.852177&amp;spn=0.025224,0.045061&amp;z=14&amp;output=embed"></iframe><br /><small>View <a href="http://maps.google.com/maps/ms?ie=UTF8&amp;hl=en&amp;msa=0&amp;msid=113252492302745252179.000484b2d0f7b533059f1&amp;ll=-32.895011,-68.852177&amp;spn=0.025224,0.045061&amp;z=14&amp;source=embed" style="color:#0000FF;text-align:left">Untitled</a> in a larger map</small>
</p>
<!--<a class="group" rel="group" href="images/mapa.jpg"><img src="images/mapa.jpg" alt="" border="0" width="410" /></a>-->
<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/argentinien.php'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
