<h3>Vertraulichkeitserklärung</h3>
<p>Ihr Recht auf Privatleben  ist uns wichtig. Nachfolgend finden Sie die Vorschriften, die wir beachten, um  die Informationen, die Sie uns beim Besuch unserer Webseite liefern zu schützen  sowie eine Erklärung über die Verwendungsart dieser Informationen. Wir  versuchen, zu jeder Zeit Ihr Privatleben zu schützen. Ein Besuch auf unserer  Webseite sollte Spaß machen und entspannend sein, Sie sollten sich sicher  fühlen und Vertrauen haben, was die uns mitgeteilten Informationen betrifft.  Für zusätzliche Fragen oder weitere Informationen zu diesem Thema, stehen wir  Ihnen gerne zur Verfügung. <br />
  <br />
  <strong>Bei einem Besuch unserer Seite erhalten wir die zu Ihnen notwendigen  Informationen. </strong><br />
Es sind persönlich identifizierbare Informationen, die für Ihre Registrierung  und das Kennenlernen Ihrer Notwendigkeiten und Wünsche benötigen. In unseren  Formularen werden Sie Ihre Kontaktinformationen angeben, wie Name, Adresse und  E-mail Anschrift. <br />
<br />
<strong>Was machen wir mit diesen Informationen?</strong> <br />
Persönliche Daten über unsere Besucher werden nicht verkauft, ausgetauscht oder  verliehen. <br />
Die Einzigen, die Zugang zu diesen Informationen haben sind die Mitarbeiter des  Sprach- und Kulturinstituts Green Fields. Unsere Mitarbeiter unterliegen den  Vorschriften für die vertrauliche Behandlung von Kundeninformationen und dem  Verbot von unerlaubtem Zugang oder Benutzung für eine Veröffentlichung.  Jeglicher Dritte, der Zugang zu unserer Seite haben muss, sei es aus  betrieblichen oder technischen Gründen, muss sich zur Vertraulichkeit gemäss  unseren Vorschriften verpflichten. Wir können diese Informationen an  Überwachungsbehörden und juristische Stellen weiterleiten, wenn dies durch die  geltenden Gesetze erfordert ist. <br />
<strong><br />
<strong>Ist das Internet sicher?</strong></strong> <br />
Leider kann es für keine Datenübertragung über das Internet eine 100%  Sicherheit geben. Daher versuchen wir Ihre persönlichen Daten so gut wie  möglich zu schützen, wir können Ihnen jedoch keine Garantie über die Sicherheit  der Informationen geben, die Sie an uns übertragen und Sie tun dies demnach auf  eigenes Risiko. Nachdem wir Ihre Daten erhalten haben, versuchen wir die  Vertraulichkeit unserer Systeme bestens zu schützen. Wir benutzen die  verfügbare Technologie um die Privatsphäre unserer Kunden in einem Höchstmaß zu  schützen. <br />
<br />
<strong>Ihre Annahme dieser Bestimmungen </strong></p>
<p><strong>Durch Ihre Benutzung dieser Seite erklären Sie sich mit unserer  Vertraulichkeitspolitik einverstanden.</strong></p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
