<h3>Ihre Unterkunft</h3>
<p>Grunds&auml;tzlich gilt, dass alle  Kurse mit Unterkunft angeboten werden. In diesem Zusammenhang handelt es sich  in erster Linie um &uuml;ber lange Jahre bew&auml;hrte Partner, die hoch motiviert sind  und Ihnen einen vielversprechenden und angenehmen Familienanschluss gew&auml;hren,  Ihnen aber auch gleichzeitig Ihre Privatsph&auml;re einr&auml;umen. In Gastfamilien ist  Fr&uuml;hst&uuml;ck inbegriffen. Halbpension ist m&ouml;glich.<br />
Auf ausdr&uuml;cklichem Wunsch stellen  wir aber auch Unterkunft ohne Familienanschluss und f&uuml;r Selbstverpfleger. Noch  vor Ihrer Anreise sprechen wir mit Ihnen die ausgesuchte Unterkunftsm&ouml;glichkeit  durch und Sie kennen bereits &bdquo;wo und mit wem&ldquo; Sie leben werden.</p>
<p>Kategorie  1:<br />
  Unterkunft  in einer Gastfamilie mit eigenem Zimmer, Bad- und K&uuml;chenmitbenutzung und  Fr&uuml;hst&uuml;ck (Sie sind f&uuml;r die Reinigkeit des Zimmers verantwortlich); Halbpension  auf Wunsch.</p>
<p>Kategorie  2:<br />
  Unterkunft  in einer Gastfamilie, eigenem Zimmer, eigenem Bad, TV, K&uuml;chenmitbenutzung und  Fr&uuml;hst&uuml;ck (Sie sind f&uuml;r die Reinigung des Zimmers verantwortlich); Halbpension  auf Wunsch.</p>
<p>Kategorie  3:<br />
  Unterkunft  in einer Gastfamilie, eigenem Zimmer, TV, eigenem Bad, K&uuml;chenmitbenutzung und  Fr&uuml;hst&uuml;ck, Pool, (Reinigung &uuml;bernimmt die Gastfamilie); Halbpension auf Wunsch.</p>
<p>Kategorie  4:<br />
  Unterkunft  in einem Apartment mit Bad, K&uuml;che, TV (Reinigung &uuml;berehmen Sie); Sie sind  Eigenversorger.</p>
<p>Kategorie  5:<br />
  Unterkunft  in einem Apartment mit Bad, K&uuml;che, TV (Reinigung &uuml;bernimmt Vermieter); Sie sind  Eigenversorger.</p>
<p>Kategorie  6:<br />
Unterkunft in einem Hotel mit  Bad, TV, Zimmerservice und Fr&uuml;hst&uuml;ck.</p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
