<h3>Teilnahmebedingungen</h3>
<p>Ich  (Name), (Reisepassnummer) biete meinen Freiwilligendienst in Bildungs-,  Erziehungs- und anderen sozialen Einrichtungen über das Sprach- und  Kulturzentrum GREEN FIELDS an. Mein Freiwilligendienst beginnt am (Datum) unter  folgenden Bedingungen:</p>
<p>1)  Beginn des Freiwilligendienstes: <br>
  2)  Der Freiwilligendienst hat freiwilligen Charakter und ich werde zu keinem  Zeitpunkt Anspruch auf Übernahme in ein vertragliches Arbeitsverhältnis  gegenüber den betreffenden Organisationen stellen.<br>
  3)  Der Freiwilligendienst geschieht auf eigene Gefahr. Für jeglichen Unfall, der  im Zusammenhang mit der Freiwilligenarbeit passiert, bestehen keinerlei  Haftungsansprüche gegen das Sprach- und Kulturzentrum GREEN FIELDS oder gegen den  Projektpartner.<br>
  4)  Während meines Aufenthaltes werde ich die Regeln und Gebräuche/Sitten des  sozio-kulturellen Umfeldes respektieren. Andernfalls besteht die Möglichkeit,  dass ich aus dem Freiwilligenprogramm herausgenommen werde. Falls ich aus  eigenem Wunsch die Projekte früher verlasse, besteht kein Anspruch auf  Erstattung der Kosten.<br>
  5)  Über das Sprach- und Kulturzentrum GREEN FIELDS habe ich Unterkunfts und Verpflegung  in Gastfamilien bzw. in den Projekten gebucht. Ich akzeptiere diese Bedingungen,  soweit sie den örtlich üblichen Gegebenheiten entsprechen.<br>
  6)  Ich werde alle vorsätzlichen Handlungen unterlassen, die meine psychische und  physische Gesundheit gefährden.<br>
  7  Fahrtkosten, zusätzliche Essenkosten, Getränke, Exkursionen, Eintrittgelder  etc. gehen auf meine eigene Rechnung. <br />
8) Ich verstehe und akzeptiere  die vorstehenden Regeln, das Profil des Freiwilligendienstes sowie die Rechte  und Pflichten vom Sprach- und Kulturzentrum GREEN FIELDS und den Freiwilligen.</p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
