<div id="videos">
                <ul>
                <li class="curved"><a href="#" onclick="view_movie();return false" title="Example 1"><img src="images/video.jpg" alt="" border="0" align="middle" /> Fiesta de la Vendimia</a></li>
                <li><br /><br /></li>
                <li class="curved"><a href="#" onclick="view_movie1();return false" title="Example 1"><img src="images/video.jpg" alt="" border="0" align="middle" /> Baile Folklore</a></li>
                <li><br /><br /></li>
                <li class="curved"><a href="#" onclick="view_movie2();return false" title="Example 1"><img src="images/video.jpg" alt="" border="0" align="middle" /> Mendoza</a></li>
                <li><br /><br /></li>
                <li class="curved"><a href="#" onclick="view_movie3();return false" title="Example 1"><img src="images/video.jpg" alt="" border="0" align="middle" /> Buenos Aires</a></li>
                </ul>
            </div>