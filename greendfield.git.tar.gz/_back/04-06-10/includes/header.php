<div class="logo">
<a href="index.php"><img src="images/logo-greenfields.png" alt="Green Fields" border="0" /></a>
</div>

<div class="webname">
    <h1>Hin und weg f&uuml;r Argentinien !!</h1>
</div>
<div class="menu-top">
    <ul>
        <li><a href="index.php"><img src="images/home.png" alt="Home" border="0" /></a></li>
        <li><a href="#"><img src="images/faq.png" alt="FAQ" border="0" /></a></li>
        <li><a href="contact-us.php"><img src="images/contact-us.png" alt="Contact Us" border="0" /></a></li>
    </ul>
</div>
<div class="flash-top curved"><object type="application/x-shockwave-flash" data="images/banner-top.swf" width="1012" height="273">
<param name="movie" value="images/banner-top.swf" />

<param name="wmode" value="transparent" />
</object>
</div>
<div class="gaucho-header">
<?php
switch(PAGE_FILENAME){
case "index.php": default:?>
	<img src="images/gaucho1.png" alt="" />
<?php break;
case "angebot-im-einzelnen.php":?> 
	<img src="images/gaucho2.png" alt="" />
<?php break;?>

<?php case "fachpraktika.php":?> 
	<img src="images/gaucho6_aprenderesp.png" alt="" />
<?php break;?>

<?php case "sprachkurse.php":?> 
	<img src="images/gaucho3_pasantias.png" alt="" />
<?php break;?>

<?php case "vertraulichkeitserklarung.php":?> 
	<img src="images/gaucho1.png" alt="" />
<?php break;?>

<?php case "voluntariat.php":?> 
	<img src="images/gaucho4_argentina.png" alt="" />
<?php break;?>

<?php }?>
</div>

