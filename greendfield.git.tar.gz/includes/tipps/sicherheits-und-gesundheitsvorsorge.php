<h3>Sicherheits- und Gesundheitsvorsorge</h3>

<p>Auslandskrankenversicherung<br />
Ausreichende Impfungen (lassen Sie sich von Ihrem Hausarzt oder in einer Apotheke beraten)<br />
Reisgepäckversicherung<br />
Gültige Haftpflichtversicherung<br />
Reiserücktrittsversicherung<br />
Mindestens für die Zeit Ihres Aufenthalts gültiger Reispass</p>


<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/tipps-fur-sie.php'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
