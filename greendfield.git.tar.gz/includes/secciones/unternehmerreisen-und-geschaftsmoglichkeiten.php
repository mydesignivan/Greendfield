<h3>Unternehmerreisen und Geschäftsm&ouml;glichkeiten</h3>

<p>Wir planen für Sie Ihre Reise auf der Suche Geschäftsmöglichkeiten in Mendoza, für Investitionen, sowie Partnern für Kooperationen, Handelbeziehungen und Joint Venture. Schwerpunkte dabei sind Wein, Agrarprodukte, Immobilien, Gastronomie und Fremdenverkehr.</p>
<p>Wir sprechen mit Ihnen die Themenbereiche Ihrer Geschäftsziele ab, stellen die Kontakte her, organisieren Ihren Aufenthalt und die Gesprächtermine.</p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
