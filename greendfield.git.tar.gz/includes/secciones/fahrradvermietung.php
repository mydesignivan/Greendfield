<h3>Fahrradvermietung</h3>

<p>Die Orientierung in der Stadt Mendoza ist wegen des Schachbrettgrundrisses der auf ebenem Gelände angelegten Stadt sehr einfach. Die Parks sind ausgedehnt und laden zum „Lustwandeln“ ein; vor allem der über 400 ha grosse Parque General San Martín, der nur 300 m von GREEN FIELDS entfernt liegt. </p>
<p>Während Ihres Kursaufenthaltes haben Sie über uns Zugang zu einem Fahrrad (Mountain Bikes), dass Sie bereits bei Ihrer Anmeldung aus Deutschland vorbestellen und reservieren können.</p>
<p>Falls Sie sich zur Miete eines der Fahrräder entscheiden, so sind Sie für die Pflege und eventuelle Reparatur während Ihrer Nutzung verpflichtet. Sie erhalten von uns ein einwandfrei funktioniernendes Fahrrad.  </p>
<p>Preise für Tagesmiete oder Wochenmiete erhalten Sie auf Anfrage.</p>
<p>Sie schliessen mit uns nach Ihrer Anreise einen kurzen Mietvertrag ab, der eine Diebstahlversicherung beinhaltet.  </p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
