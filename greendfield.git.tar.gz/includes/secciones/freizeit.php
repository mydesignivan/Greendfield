<h3>Freizeit</h3>

<p>Mendoza als Industrie-, Handels-, Kongress- und Universitätszentrum ist ebenfalls ein international anerkanntes Tourismusziel zu allen Jahreszeiten. Die Stadt bietet jegliche Freizeitbeschäftigung einer modernen Großstadt mit ausgeprägtem Kultur- und Nachtleben sowie Abenteuer und Entspannung in den umliegenden Regionen der Oasen und den Anden. An sieben Tagen der Woche wird in den zahllosen Bars, Restaurants, Strassencafés und Dikotheken die Nacht zum Tage. Das mediterranes Flair auf den breiten und baumbstandenen Strassen Mendozas lässt sich in den Monaten November bis April nicht verleugnen. In dieser Hinsicht ist Mendoza einzigartig in Argentinien und auch im Vergleich zu vielen Städten Südamerikas.</p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
