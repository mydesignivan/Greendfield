<h3>Wer kann an unserem Programm teilnehmen</h3>

<p>Sie sind mindestens 18 Jahre alt und haben das Bed&uuml;rfnis, nach Ihrer Berufsausbildung, noch vor dem Abitur, nach dem Abitur oder während des Studiums; aber auch zum Ende oder nach dem Studium, und bevor Sie in die Arbeits- und Jobwelt eintreten, eine kurzzeitige Freiwilligentätigkeit von mindestens 4 Wochen und maximal 6 Monaten mit tiefgreifender menschlicher oder umweltorientierter Ausrichtung auszuprobieren. Das Voluntariat oder Praktikum kann bei entsprechender Auslegung auch als angewandtes Studienpraktikum in Deutschland anerkannt werden; z.B. in einem Krankenhaus, einem Tierzuchtunternehmen, einem Naturreservat oder einem Weinbaubetrieb. </p>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
