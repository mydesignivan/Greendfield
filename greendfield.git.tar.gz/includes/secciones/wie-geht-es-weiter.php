<h3>Wie geht es weiter?</h3>

<p>Nach einer ersten Sichtung Ihrer Unterlagen erhalten Sie eine Bestätigung über die Programmaufnahme und den Eingang in den Auswahlprozess. Sie werden aufgefordert, eine Anmeldegebühr von Euro 80,- im Falle eines Praktikums und Voluntariats zu leisten. Diese Anmeldegebühr wird zurückerstattet (- 10 % wegen Bankunkosten), falls es durch uns nicht zur Durchführung des Programms kommt. </p>
<p>GREEN FIELDS erstellt auf Basis Ihrer Anmeldung ein konkretes Teilnahmeangebot gemäß Ihrer Vorgaben. Dabei werden der Zeitraum, der Sprachunterricht, die Unterkunft und sonstige Leistungen sowie die in Frage kommenden Praktikumsbereiche festgelegt. </p>
<p>Erst nachdem Sie dieses Teilnahmeangebot unterschrieben zurücksenden (Fax oder digital), wird Ihre Programmteilnahme verbindlich und die Vorbereitungen für Ihren Auslandsaufenthalt können beginnen. Die jeweilige Ortsrepräsentanz beginnt mit der Praktikumsstellenorganisation bzw. den Vorbereitungen für Ihren Aufenthalt. Sobald die Praktikumsstelle feststeht, erhalten Sie eine Kurzbeschreibung über Art und Inhalt der Praktikumsstelle. Mindestens eine Woche vor Ihrem Abflug überweisen Sie den vereinbarten Betrag gemäss Auswahl Ihres Programms.</p>

<a href="javascript:void(open_popup('<?=$_GET['filename'];?>'))">Preisliste 2010 Green Fields</a>

<div class="backPage"><a href="#" onclick="Slider.slide({url: 'includes/<?php echo $_GET["returnpage"];?>'}, 1); return false;"><img src="images/button_back.png" alt="Volver" title="Volver" border="0" align="absmiddle" />&nbsp;Volver</a></div>
